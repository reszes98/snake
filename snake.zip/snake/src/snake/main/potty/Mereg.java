package snake.main.potty;

public class Mereg extends Potty{
/**
 * Konstruktor, be�ll�tja az �j x, y, �s id �rt�keket
 * @param xi	�j x koordin�ta
 * @param yi	�j y koordin�ta
 */
	public Mereg(int xi, int yi) {
		super();
		id = 3;
		x = xi;
		y = yi;
	}
}
