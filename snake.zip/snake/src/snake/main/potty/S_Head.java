package snake.main.potty;

public class S_Head extends Potty {
	/**
	 * Konstruktor, be�ll�tja az x, y �s az id v�ltoz�kat(id mindig 5 lesz)
	 * @param xi	Az �j x koordin�ta
	 * @param yi	Az �j y koordin�ta
	 */
	public S_Head(int xi, int yi) {
		super();
		id = 5;
		x = xi;
		y = yi;
	}
}
