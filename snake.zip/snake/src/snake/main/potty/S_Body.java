package snake.main.potty;

public class S_Body extends Potty {
	/**
	 * Konstruktor be�ll�tja az x, y, �s id v�ltoz�kat(mindig 4 lesz az id)
	 * @param xi az �j x koordin�ta
	 * @param yi az �j y koordin�ta
	 */
	public S_Body(int xi, int yi) {
		super();
		id = 4;
		x = xi;
		y = yi;
	}
}
